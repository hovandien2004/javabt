package Laptrinhgiaodien;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.ItemEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JTabbedPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.MouseEvent;

public class frmBanHang extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtgia;
	private JTextField txtton;
	private JTextField txtsl;
	private JTextField txtthanhtien;
	JComboBox cmbHang = new JComboBox();
	
	void NapBang(ArrayList<String> ds) {
		//Tao mo hinh bang
		DefaultTableModel mh = new DefaultTableModel();
		// Tao cot
		mh.addColumn("Ma hang");mh.addColumn("Ten hang");
		mh.addColumn("So luong");mh.addColumn("Gia");
//		Object[] t = new Object[4];
//		t[0] = "Mh1"; t[1] = "abc"; t[2] = 10; t[3] = 10000;
		for(String h:ds) {
			String[] t = h.split(";");
			mh.addRow(t);
		}
		
		
		
		//Dua mo hinh vao jtable
		table.setModel(mh);
	}
	void NapBang2(ArrayList<String> ds) {
		//Tao mo hinh bang
		DefaultTableModel mh = new DefaultTableModel();
		// Tao cot
		mh.addColumn("Ten hang");
		mh.addColumn("So luong");mh.addColumn("Gia");
		mh.addColumn("Thanh tien");
		mh.addColumn("Ngay mua");
//		Object[] t = new Object[4];
//		t[0] = "Mh1"; t[1] = "abc"; t[2] = 10; t[3] = 10000;
		for(String h:ds) {
			String[] t = h.split(";");
			mh.addRow(t);
		}
		
		
		
		//Dua mo hinh vao jtable
		table.setModel(mh);
	}
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmBanHang frame = new frmBanHang();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	ArrayList<String> ds = new ArrayList<String>();
	ArrayList<String> ds2 = new ArrayList<String>();
	private JTable table;
	private JTable table_1;
	public frmBanHang() {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowOpened(WindowEvent e) {
				try {
					FileReader f1 = new FileReader("hang.txt");
					BufferedReader r = new BufferedReader(f1);
					while(true) {
						String st = r.readLine();
						
						
						
						if(st == null || st == "")break;
						System.out.println(st);
						cmbHang.addItem(st.split(";")[1]);
						ds.add(st);
						
					}r.close();
					
				} catch (Exception e2) {
					System.out.println("loi");
					e2.printStackTrace();
					
				}
				NapBang(ds);
			}
		});
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 606, 502);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Chọn hàng");
		lblNewLabel.setBounds(25, 11, 84, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Giá");
		lblNewLabel_1.setBounds(25, 36, 84, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Số Lượng tồn");
		lblNewLabel_2.setBounds(25, 61, 84, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Nhập số lượng");
		lblNewLabel_3.setBounds(25, 86, 84, 14);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Thành Tiền");
		lblNewLabel_4.setBounds(25, 111, 84, 14);
		contentPane.add(lblNewLabel_4);
		
		cmbHang.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				String th=cmbHang.getSelectedItem().toString();
				for(String h:ds ) {
					String[] t=h.split("[;]");
					if(t[1].equals(th)) {
						txtgia.setText(t[3]);
						txtton.setText(t[2]);
					}
				}
			}
		});
		
		
		
		
		
		
		
		
		
		
		
		cmbHang.setBounds(149, 7, 156, 22);
		contentPane.add(cmbHang);
		
		txtgia = new JTextField();
		txtgia.setBounds(149, 33, 156, 20);
		contentPane.add(txtgia);
		txtgia.setColumns(10);
		
		txtton = new JTextField();
		txtton.setBounds(149, 58, 156, 20);
		contentPane.add(txtton);
		txtton.setColumns(10);
		
		txtsl = new JTextField();
		
		
		txtsl.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()==10) {
					Long a=Long.parseLong(txtgia.getText());
					Long b=Long.parseLong(txtsl.getText());
					Long kq=a*b;
					txtthanhtien.setText(kq.toString());
					}
					if(e.getKeyCode()==27) {
						System.exit(1);
					}
			}
		});
		
		
		txtsl.setBounds(149, 83, 156, 20);
		contentPane.add(txtsl);
		txtsl.setColumns(10);
		
		txtthanhtien = new JTextField();
		txtthanhtien.setBounds(149, 108, 156, 20);
		contentPane.add(txtthanhtien);
		txtthanhtien.setColumns(10);
		
//		JButton btnNewButton = new JButton("Bán");
//		btnNewButton.addMouseListener(new MouseAdapter() {
//			@Override
//			public void mouseClicked(MouseEvent e) {
//				try {
//					Date d=new Date();
//					SimpleDateFormat date=new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
//					String ngay = date.format(d);
//					
//					FileWriter f2=new FileWriter("DaBan.txt");
//					PrintWriter ghi=new PrintWriter(f2);
//					
//					String tenhang=cmbHang.getSelectedItem().toString();
//					String gia=txtgia.getText();
//					String SoLuong=txtsl.getText();
//					String ThanhTien=txtthanhtien.getText();
//					String t = tenhang+";"+gia+";"+SoLuong+";"+ThanhTien+";"+ngay;
//					ghi.println(t);
//					ghi.close();
//					System.out.println("Da luu hang");
//				} 
//				catch (Exception e2) {
//					e2.printStackTrace();
//				}
//				
//			}
//				
//		
//		});
//		btnNewButton.setForeground(Color.RED);
//		btnNewButton.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//					
//			}
//		});
//		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
//		btnNewButton.setBounds(149, 153, 89, 23);
//		contentPane.add(btnNewButton);
//		
		JTabbedPane tabbedPane_1 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_1.setBounds(25, 187, 540, 191);
		contentPane.add(tabbedPane_1);
		
		JScrollPane scrollPane = new JScrollPane();
		tabbedPane_1.addTab("New tab", null, scrollPane, null);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		table_1 = new JTable();
		tabbedPane_1.addTab("New tab", null, table_1, null);
		
		JButton btnNewButton1 = new JButton("Bán");
		btnNewButton1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String th = cmbHang.getSelectedItem().toString();
				String gia=txtgia.getText();
				String SoLuong=txtsl.getText();
				String ThanhTien=txtthanhtien.getText();
				Date n = new Date();
				SimpleDateFormat dd = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
				String ngay = dd.format(n);
				String tt = th+";"+gia+";"+SoLuong+";"+ThanhTien+";"+ngay;
				ds2.add(tt);
				NapBang2(ds2);
				try {
					FileWriter f = new FileWriter("DaBan.txt", true);
					PrintWriter ghi = new PrintWriter(f);
					ghi.println(tt);
					ghi.close();
					JOptionPane.showMessageDialog(null, "Da Ban");
				} catch (Exception e2) {
					e2.printStackTrace();
					// TODO: handle exception
				}
			}
		});
		btnNewButton1.setForeground(Color.RED);
		btnNewButton1.setBackground(Color.WHITE);
		btnNewButton1.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton1.setBounds(149, 156, 89, 23);
		contentPane.add(btnNewButton1);
	}
}
