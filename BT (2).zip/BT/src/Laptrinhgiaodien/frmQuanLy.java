package Laptrinhgiaodien;

import java.awt.EventQueue;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTabbedPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.FileReader;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class frmQuanLy extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtmahang;
	private JTextField txttenhang;
	private JTextField txtgia;
	private JTextField txtsl;
	private JTable table;
	ArrayList<String> ds = new ArrayList<String>();

	
	void NapBang(ArrayList<String> ds) {
		//Tao mo hinh bang
		DefaultTableModel mh = new DefaultTableModel();
		// Tao cot
		mh.addColumn("Ma hang");mh.addColumn("Ten hang");
		mh.addColumn("So luong");mh.addColumn("Gia");
//		Object[] t = new Object[4];
//		t[0] = "Mh1"; t[1] = "abc"; t[2] = 10; t[3] = 10000;
		for(String h:ds) {
			String[] t = h.split(";");
			mh.addRow(t);
		}
		
		
		
		//Dua mo hinh vao jtable
		table.setModel(mh);
	}
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmQuanLy frame = new frmQuanLy();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public frmQuanLy() {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowOpened(WindowEvent e) {
				try {
					FileReader f1 = new FileReader("hang.txt");
					BufferedReader r = new BufferedReader(f1);
					while(true) {
						String st = r.readLine();
						
						
						
						if(st == null || st == "")break;
						System.out.println(st);
						//cmbHang.addItem(st.split(";")[1]);
						ds.add(st);
						
					}r.close();
					
				} catch (Exception e2) {
					System.out.println("loi");
					e2.printStackTrace();
					
				}
				NapBang(ds);
				
			}
		});
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 736, 421);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Mã hàng");
		lblNewLabel.setBounds(21, 11, 76, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Tên hàng");
		lblNewLabel_1.setBounds(21, 36, 76, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Giá");
		lblNewLabel_2.setBounds(21, 61, 76, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Số lượng");
		lblNewLabel_3.setBounds(21, 86, 76, 14);
		contentPane.add(lblNewLabel_3);
		
		txtmahang = new JTextField();
		txtmahang.setBounds(107, 8, 403, 20);
		contentPane.add(txtmahang);
		txtmahang.setColumns(10);
		
		txttenhang = new JTextField();
		txttenhang.setBounds(107, 33, 403, 20);
		contentPane.add(txttenhang);
		txttenhang.setColumns(10);
		
		txtgia = new JTextField();
		txtgia.setBounds(107, 58, 403, 20);
		contentPane.add(txtgia);
		txtgia.setColumns(10);
		
		txtsl = new JTextField();
		txtsl.setBounds(107, 83, 403, 20);
		contentPane.add(txtsl);
		txtsl.setColumns(10);
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String mh = txtmahang.getText();
				String th = txttenhang.getText();
				String gia = txtgia.getText();
				String sl = txtsl.getText();
				String tt = mh + ";" + th+";"+gia+";"+sl;
				ds.add(tt);
				NapBang(ds);
			}
		});
		btnNewButton.setBounds(10, 131, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Delete");
		btnNewButton_1.setBounds(107, 131, 89, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Update");
		btnNewButton_2.setBounds(211, 131, 89, 23);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Find");
		btnNewButton_3.setBounds(312, 131, 89, 23);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Save file");
		btnNewButton_4.setBounds(421, 131, 89, 23);
		contentPane.add(btnNewButton_4);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(21, 175, 646, 184);
		contentPane.add(tabbedPane);
		
		JScrollPane scrollPane = new JScrollPane();
		tabbedPane.addTab("Ds các hàng", null, scrollPane, null);
		
		table = new JTable();
		scrollPane.setViewportView(table);
	}
}
