import java.util.ArrayList;
import java.util.List;

public class Management {

	public static void main(String[] args) {
		List<Htron> A=new ArrayList<Htron>();
		A.add( new Htron(5));
		A.add( new Htron(7));
		A.add(new Htron(15));
		A.add(new Htron(12));
		A.add(new Htron(3));
		
			

	}

}
