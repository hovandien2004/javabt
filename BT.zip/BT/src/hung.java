import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class hung extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txta;
	private JTextField txtb;
	private JTextField txtkq;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					hung frame = new hung();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public hung() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setForeground(Color.GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("a=");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblNewLabel.setBounds(59, 54, 46, 42);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("b=");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblNewLabel_1.setBounds(59, 107, 46, 42);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("kq=");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblNewLabel_2.setBounds(59, 164, 46, 42);
		contentPane.add(lblNewLabel_2);
		
		txta = new JTextField();
		txta.setFont(new Font("Tahoma", Font.PLAIN, 25));
		txta.setBounds(115, 54, 178, 37);
		contentPane.add(txta);
		txta.setColumns(10);
		
		txtb = new JTextField();
		txtb.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()==10) {//Neu nguoi dung nhan Enter
					Long a=Long.parseLong(txta.getText());
					Long b=Long.parseLong(txtb.getText());
					Long kq=a+b;
					txtkq.setText(kq.toString());
				}
				if(e.getKeyCode()==27)//Neu nguoi dung nhan ESC
					System.exit(1);//Dong chuong trinh
			}
		});
		txtb.setFont(new Font("Tahoma", Font.PLAIN, 25));
		txtb.setBounds(115, 107, 178, 37);
		contentPane.add(txtb);
		txtb.setColumns(10);
		
		txtkq = new JTextField();
		txtkq.setFont(new Font("Tahoma", Font.PLAIN, 25));
		txtkq.setBounds(115, 164, 178, 37);
		contentPane.add(txtkq);
		txtkq.setColumns(10);
		
		JButton btnNewButton = new JButton("+");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//Lay ve gia tri cua txta va doi ra so
				Long a=Long.parseLong(txta.getText());
				//Lay ve gia tri cua txtb va doi ra so
				Long b=Long.parseLong(txtb.getText());
				Long kq=a+b;
				txtkq.setText(kq.toString());
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton.setForeground(Color.BLACK);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setBounds(20, 217, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("-");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//Lay ve gia tri cua txta va doi ra so
				Long a=Long.parseLong(txta.getText());
				//Lay ve gia tri cua txtb va doi ra so
				Long b=Long.parseLong(txtb.getText());
				Long kq=a-b;
				txtkq.setText(kq.toString());
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton_1.setForeground(Color.BLACK);
		btnNewButton_1.setBounds(125, 217, 89, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("*");
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//Lay ve gia tri cua txta va doi ra so
				Long a=Long.parseLong(txta.getText());
				//Lay ve gia tri cua txtb va doi ra so
				Long b=Long.parseLong(txtb.getText());
				Long kq=a*b;
				txtkq.setText(kq.toString());
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton_2.setForeground(Color.BLACK);
		btnNewButton_2.setBounds(224, 217, 89, 23);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("/");
		btnNewButton_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//Lay ve gia tri cua txta va doi ra so
				Long a=Long.parseLong(txta.getText());
				//Lay ve gia tri cua txtb va doi ra so
				Long b=Long.parseLong(txtb.getText());
				if(b!=0) {
					Long kq=a/b;
					txtkq.setText(kq.toString());
				}else
					JOptionPane.showConfirmDialog(null,"Dung co dua");
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton_3.setForeground(Color.BLACK);
		btnNewButton_3.setBounds(323, 217, 89, 23);
		contentPane.add(btnNewButton_3);
	}
}
