import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class vd {

	public static void main(String[] args) {
		try {
			//Khai bao 1 mang dong, moi phan tu co kieu String
			ArrayList<String> ds= new ArrayList<String>();
			//Mo file hang.txt de doc
			FileReader f= new FileReader("hang.txt");
			//Luu file vao bo dem
			BufferedReader bd= new BufferedReader(f);
			//Duyet file
			while (true) {
				//Doc ra 1 dong
				String st=bd.readLine();
				//Kiem tra ket thuc file
				if(st==null||st=="") break;
				ds.add(st);//Luu st vao mang ds
				System.out.println(st);
				}
			bd.close();//Dong file
			System.out.println("Hang trong mang c1");
			for(String h: ds) {//x;Xang;100;24000
				String[] t=h.split("[;]");
				System.out.println(t[0]);
				System.out.println(t[1]);
				System.out.println(t[2]);
				System.out.println(t[3]);
				System.out.println("-----------");
				//System.out.println(h);
			}
			//System.out.println("Hang trong mang c2");
			//int n=ds.size();
			//for(int i=0;i<n;i++) {
			//	System.out.println(ds.get(i));
			//}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		//Nhập vào mã hàng-> in ra tên hàng và giá
			Scanner nhap= new Scanner(System.in);
			System.out.println("Nhap ma hang:");
			String mh=nhap.nextLine();
			//Duyet qua cac mat hang
			for(String h: ds) {//x;Xang;100;24000
				String[] t=h.split("[;]");//Che hang ra thanh 4 thong tin
				if(t[0].toLowerCase().equals(mh.toLowerCase())) {
				System.out.println(t[1]);//In ra ten hang
				System.out.println(t[3]);//In ra gia
				}
			}
		//Nhập vào 1 tên hàng-> in ra các hàng tìm được (Tìm tương đối)
			System.out.println("Nhap ten hang:");
			String th=nhap.nextLine();
			for(String h:ds) {
				String[] t=h.split("[;]");//Che hang ra thanh 4 thong tin
				if(t[1].toLowerCase().contains(th.toLowerCase())) {
					System.out.println(h);
				}
			}
		//In ra tên hàng có giá lớn nhất
			String[] t=ds.get(0).split("[;]");//Lay ra mat hang dau tien va che
			Long max= Long.parseLong(t[3]);//Lay ra gia cua mat hang dau tien
			String tenhang=t[1];//Lay ra ten hang cua mat hang dau tien
			int n=ds.size();//Lay ra kich co cua mang
			for(int i=1;i<n;i++) {//Duyet tu phan tu thu 1 tro di
				String[] tt=ds.get(i).split("[;]");//Che hang ra 4 thong tin
				if(max<Long.parseLong(tt[3])) {
					max= Long.parseLong(tt[3]);//Luu lai max
					tenhang=tt[1];//Luu lai ten hang
				}
			}
			System.out.println("Ten hang: "+tenhang+"\nMax gia: "+ max);
			//Mo file ra de ghi
			FileWriter f2= new FileWriter("luuhang.txt",true);
			//Tao ra bo dem de ghi
			PrintWriter ghi= new PrintWriter(f2);
			for(String h: ds) {//Duyet mang
				ghi.println(h);//Luu h vao file
			}
			ghi.close();
			System.out.println("Da luu");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}