package bean;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Nguoi {
	private String hoten;
	private Boolean gioitinh;
	private Date ngaysinh;
	
	
	
	
	
	@Override
	public String toString() {		
		
			SimpleDateFormat dd = new SimpleDateFormat("dd/MM/yyyy");
			String ngaysinh1 = dd.format(ngaysinh);
				
			return "Nguoi [hoten=" + hoten + ", gioitinh=" + gioitinh + ", ngaysinh=" + ngaysinh1 + "]" + "Tuoi= " + gettuoi();
	}
	public Nguoi(Boolean gioitinh, Date ngaysinh) {
		super();
		this.gioitinh = gioitinh;
		this.ngaysinh = ngaysinh;
	}
	public Nguoi(String hoten, Boolean gioitinh, Date ngaysinh) {
		super();
		this.hoten = hoten;
		this.gioitinh = gioitinh;
		this.ngaysinh = ngaysinh;
	}
	public Nguoi() {
		super();
		// TODO Auto-generated constructor stub
	}
	public void setHoten(String hoten) {
		this.hoten = hoten;
	}
	public Boolean getGioitinh() {
		return gioitinh;
	}
	public void setGioitinh(Boolean gioitinh) {
		this.gioitinh = gioitinh;
	}
	public Date getNgaysinh() {
		return ngaysinh;
	}
	public void setNgaysinh(Date ngaysinh) {
		this.ngaysinh = ngaysinh;
	}
	public String gethoten() {
		return hoten;
	}
	
	public int gettuoi() {
		SimpleDateFormat dd = new SimpleDateFormat("dd/MM/yyyy");
		String ngaysinh1 = dd.format(ngaysinh);
		int namsinh = Integer.parseInt(ngaysinh1.split("[/]")[2]) ;
		Date d = new Date();
		String namht = dd.format(d);
		int namhientai = Integer.parseInt(namht.split("[/]")[2]) ;
		
		return namhientai-namsinh;
	}
	ArrayList<String> ds = new ArrayList<String>();
	
	
}
