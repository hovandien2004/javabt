package dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

import bean.Nguoi;

public class Nguoidao {
	public ArrayList<Nguoi> getds() throws Exception{
		SimpleDateFormat dd = new SimpleDateFormat("dd/MM/yy");
		Nguoi n1 = new Nguoi("ha", true, dd.parse("10/11/2004"));
		Nguoi n2 = new Nguoi("hung", false, dd.parse("20/01/2004"));
		Nguoi n3 = new Nguoi("Nhu", true, dd.parse("15/12/1995"));
		Nguoi n4 = new Nguoi("Phong", false, dd.parse("23/05/1990"));
		ArrayList<Nguoi> ds = new ArrayList<Nguoi>();
		ds.add(n1);ds.add(n2);ds.add(n3);ds.add(n4);
		return ds;
	}
}
