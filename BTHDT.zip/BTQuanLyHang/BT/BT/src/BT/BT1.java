package BT;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class BT1 {

	public static void main(String[] args) {
		//Khai bao mot mang dong, moi phan tu cua mang co kieu string
		ArrayList<String> ds = new ArrayList<String>();
		
		try {
			FileReader f1 = new FileReader("hang.txt");
			BufferedReader r = new BufferedReader(f1);
			while(true) {
				String st = r.readLine();
				
				
				
				if(st == null || st == "")break;
				System.out.println(st);
				ds.add(st);
				
			}r.close();
		} catch (Exception e) {
			System.out.println("loi");
			e.printStackTrace();
			
		}
		System.out.println("Du lieu trong mang: ");
		for(String h:ds) {
			System.out.println(h);
		}
		//1
		
		
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap ma hang: ");
		String nhap = sc.nextLine();
		for(String h:ds) {
			String[] che = h.split(";");
			if(che[0].trim().toLowerCase().equals(nhap.trim().toLowerCase())) {
				System.out.println(che[3]);
			}
			
		}
		
		String[] che = ds.get(0).split("[;]");
		Long max = Long.parseLong(che[3]);//lay gia cua mat hang dau
		String th = che[1];//lay ten cua mat hang dau
		int n = ds.size();
		for(int i = 1; i < n; i++) {
			String[] che1 = ds.get(i).split("[;]");
			if(max < Long.parseLong(che1[3])) {
				max = Long.parseLong(che1[3]);
				th = che1[1];
			}
		}
		System.out.println("Ten hang: " + th + "; Gia lon nhat: " + max);
		
		System.out.println("Nhap ten hang: ");
		String tenhang = sc.nextLine();
		for(String h:ds) {
			String[] che2 = h.split(";");
			if(che2[1].trim().toLowerCase().equals(tenhang.trim().toLowerCase())) {
				System.out.println(h);
			}
			
		}
		
		
		
		//mo file de ghi
		try {
			FileWriter f2 = new FileWriter("Luu hang.txt");
			PrintWriter ghi = new PrintWriter(f2);
			for(String h: ds) {
				ghi.println(h);
			}ghi.close();
			System.out.println("Da luu hang");
		} catch (Exception e) {
			System.out.println("Loi");
			e.printStackTrace();
		}
		
		
		
		
	}

}
