import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;

public class bai1 {

		public static void main(String[] args) {
		 Scanner sc=new Scanner(System.in);
/*	System.out .print("Nhap n: ");
			int n=sc.nextInt();
			int A[]=new int[n];
			for(int i=0;i<n;i++) {
				Random r =new Random();
				A[i]= r.nextInt(1,100);
				System.out.print(A[i]+" "-);

	}
				int dem=0;
				for(int i=0;i<n;i++) ;
				if (A[i]%2==0)dem++;
				System.out.print("Tong: "+tong);
}*/
	/*tring []A=new String[5];
			for (int i=0;i<A.length-1;i++)
				for(int j=j+1;j<A.length;j++)
					if(A[i].compareTo(A[j]>0){
						String tam=A[j];
						A[i]=A[j];
						A[j]=tam;
				
					}
					for (String x: A)
				System.out.print(x+","); */
		/*	ArrayList<String>A= new ArrayList<String>();
					A.add("Ti");
					A.add("Suu");
					A.add("Dan");
					A.add("Mao");
					A.add("Thin");
					Collections.sort(A, Collections.reverseOrder();
					for (String x: A)
						System.out.print(x+","); */
						
	   /*  	Random ra=new Random();
	     	ArrayList<Integer> A= new ArrayList<Integer>();
	     	System.out.print("Nhap n phan tu: ");
	     	int n=sc.nextInt();
	     	ArrayList<Integer>Schan= new ArrayList<Integer>();
	     	ArrayList<Integer>Sle=new ArrayList<Integer>();
	     	for(int i=0;i<n;i++)
	     	{
	     		a.add(ra.nextInt
	     	
	     	}*/
	     
	     	
	
	     	}
		{
			
		}
		 


		private static ArrayList<Integer> generateRandomArrayList(int n) {
			// TODO Auto-generated method stub
			return null;
		}
}		