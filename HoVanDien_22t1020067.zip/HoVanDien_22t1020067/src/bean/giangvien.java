package bean;

public class giangvien extends cha {
	private String manv;
	private String lhd;
	private double hsl;
	private double phucap;
	public giangvien() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	



	public giangvien(String manv,String hoten,  String lhd, double hsl, double phucap) {
		super(hoten);
		this.manv = manv;
		this.lhd = lhd;
		this.hsl = hsl;
		this.phucap = phucap;
	}


	public String getManv() {
		return manv;
	}
	public void setManv(String manv) {
		this.manv = manv;
	}
	
	public String getLhd() {
		return lhd;
	}
	public void setLhd(String lhd) {
		this.lhd = lhd;
	}
	public double getHsl() {
		return hsl;
	}
	public void setHsl(double hsl) {
		this.hsl = hsl;
	}
	public double getPhucap() {
		return phucap;
	}
	public void setPhucap(double phucap) {
		this.phucap = phucap;
	}
	@Override
	public String toString() {
		return manv + ";" +super.toString()+ ";" + lhd + ";" + hsl + ";" + phucap;
	}
	
	
	
}
