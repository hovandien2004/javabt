package bean;

public class nhanvien extends cha{
	private String manv;
	private String lhd;
	private double hsl;
	
	
	
	
	


	public nhanvien() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public String getManv() {
		return manv;
	}
	public nhanvien(String manv,String hoten, String lhd, double hsl) {
	super(hoten);
	this.manv = manv;
	this.lhd = lhd;
	this.hsl = hsl;
}
	public void setManv(String manv) {
		this.manv = manv;
	}
	
	
	public String getLhd() {
		return lhd;
	}
	public void setLhd(String lhd) {
		this.lhd = lhd;
	}
	public double getHsl() {
		return hsl;
	}
	public void setHsl(double hsl) {
		this.hsl = hsl;
	}
	@Override
	public String toString() {
		return manv + ";" +super.toString()+ ";" + lhd + ";" + hsl;
	}
	
	
}
