package bo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

import bean.cha;
import bean.giangvien;
import bean.nhanvien;
import bean.cha;
import dao.nguoidao;



public class nguoibo {
	nguoidao ndao = new nguoidao();
	ArrayList<cha> ds;
	public ArrayList<cha> getds() throws Exception{
		ds = ndao.getds();
		return ds;
	}
	public void hienthi() throws Exception{
		for(cha n:ds) {
			System.out.println(n.toString());
		}
	}
	public void ghifile() throws Exception{
		
			FileWriter fw = new FileWriter("ketqua.txt");
			BufferedWriter bw = new BufferedWriter(fw);
			for(cha n:ds) {
				bw.write(n.toString() +"\n");
			}bw.close();
			System.out.println("Ghi file thanh cong");
		
	}
	ArrayList<nhanvien> nv = new ArrayList<nhanvien>();
		ArrayList<giangvien> gv = new ArrayList<giangvien>();
	public void cau3() throws Exception{
		
		FileReader fr = new FileReader("ketqua.txt");
		BufferedReader br = new BufferedReader(fr);
		
		while(true) {
			String st = br.readLine();
			if(st == null || st == "") break;
			String[] t = st.split("[;]");
			if(t.length == 4) {
				nhanvien nv1 = new nhanvien(t[0], t[1], t[2], Double.parseDouble(t[3]));
				nv.add(nv1);
			}
			if(t.length == 5) {
				giangvien gv1 = new giangvien(t[0], t[1], t[2], Double.parseDouble(t[3]),Double.parseDouble(t[4]));
				gv.add(gv1);
			}
			
		}br.close();
		
		System.out.println("DS Nhan vien: ");
		for(nhanvien nv1:nv) {
			System.out.println(nv1.toString());
		}
		System.out.println("DS giang vien:");
		for(giangvien gv1:gv) {
			System.out.println(gv1.toString());
		}
	}
	
	
	public void cau4() {
		try {
			FileWriter fr = new FileWriter("f1.txt");
			BufferedWriter br = new BufferedWriter(fr);
			for(nhanvien nv1: nv) {
				br.write(nv1.toString() + "\n");
			}br.close();
			FileWriter ok = new FileWriter("f2.txt");
			BufferedWriter haha = new BufferedWriter(ok);
			for(Object gv1: gv) {
				haha.write(gv1.toString() + "\n");
			}haha.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	
	public void cau5() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap ten tim kiem: ");
		String nhap = sc.nextLine();
		int check =- 1;
		for(cha n:ds) {
			if(n.getHoten().contains(nhap)) {
				System.out.println(n.toString());
				check = 1;
			}
		}if(check == -1) {
			System.out.println("khong co ten muon tim");
		}
	}
	
	
}
