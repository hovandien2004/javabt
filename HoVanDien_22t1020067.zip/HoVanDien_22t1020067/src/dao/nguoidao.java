package dao;

import java.io.BufferedReader;
import java.io.FileReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;


import bean.cha;
import bean.giangvien;
import bean.nhanvien;

public class nguoidao {
	
	public ArrayList<cha> getds() throws Exception{
		ArrayList<cha> ds = new ArrayList<cha>();
		try {
			FileReader fr = new FileReader("ds.txt");
			BufferedReader br = new BufferedReader(fr);
			
			while(true) {
				String st = br.readLine();
				if(st == null || st == "") break;
				String[] t = st.split("[;]");
				if(t.length == 4 && (t[2].equals("hopdong") || t[2].equals("chinhthuc"))) {
					nhanvien nv = new nhanvien(t[0],t[1],t[2],Double.parseDouble(t[3])); 
					ds.add(nv);
					
				}
				if(t.length == 5 && (t[2].equals("hopdong") || t[2].equals("chinhthuc"))) {
					giangvien gv = new giangvien(t[0],t[1],t[2],Double.parseDouble(t[3]),Double.parseDouble(t[4])); 
					
					gv.setPhucap(Double.parseDouble(t[4]));
					ds.add(gv);
				}
				
				
			}br.close();
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return ds;
	}
	public ArrayList<nhanvien> getnv() throws Exception{
		ArrayList<nhanvien> tam = new ArrayList<nhanvien>();
		for(cha n: getds()) {
			if(n instanceof nhanvien) {
				tam.add((nhanvien)n);
			}
		}return tam;
	}
	
	public ArrayList<giangvien> getgv() throws Exception{
		ArrayList<giangvien> tam = new ArrayList<giangvien>();
		for(cha n: getds()) {
			if(n instanceof giangvien) {
				tam.add((giangvien)n);
			}
		}return tam;
	}
	

	
}
