package view;

import java.util.ArrayList;

import bean.cha;
import bo.nguoibo;
import dao.nguoidao;

public class nguoiview {

	public static void main(String[] args) {
		try {
			nguoibo nbo = new nguoibo();
			ArrayList<cha> ds = nbo.getds();
			System.out.println("Danh sach: ");
			nbo.hienthi();
			nbo.ghifile();
			nbo.cau3();
			nbo.cau4();
			nbo.cau5();
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}

}
