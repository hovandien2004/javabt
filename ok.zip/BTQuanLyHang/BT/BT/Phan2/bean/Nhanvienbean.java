package bean;

import java.util.Date;

public class Nhanvienbean extends  Nguoi{
	private String manv;
	private String email;
	private String sodt;
	private Double hsl;
	
	
	
	
	
	public Nhanvienbean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
public Nhanvienbean(String manv, String hoten, Boolean gioitinh, Date ngaysinh, String email, String sodt,
			Double hsl) {
		super(hoten, gioitinh, ngaysinh);
		this.manv = manv;
		this.email = email;
		this.sodt = sodt;
		this.hsl = hsl;
	}

//	public Nhanvienbean(String manv, String hoten ,Boolean gioitinh ,String email, String sodt, Double hsl) {
//		super();
//		this.manv = manv;
//		this.email = email;
//		this.sodt = sodt;
//		this.hsl = hsl;
//	}
	public String getManv() {
		return manv;
	}
	public void setManv(String manv) {
		this.manv = manv;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSodt() {
		return sodt;
	}
	public void setSodt(String sodt) {
		this.sodt = sodt;
	}
	public Double getHsl() {
		return hsl;
	}
	public void setHsl(Double hsl) {
		this.hsl = hsl;
	}
	@Override
	public String toString() {
		return manv + ";"+super.toString() + email + ";" + sodt + ";" + hsl;
	}
	
	
	
}
