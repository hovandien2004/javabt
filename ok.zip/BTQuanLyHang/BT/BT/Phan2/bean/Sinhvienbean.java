package bean;

import java.util.Date;

public class Sinhvienbean extends Nguoi {
	private String masv;
	private String tenlop;
	private Double dtb;
	
	
	
	public String getMasv() {
		return masv;
	}
	public void setMasv(String masv) {
		this.masv = masv;
	}
	public String getTenlop() {
		return tenlop;
	}
	public void setTenlop(String tenlop) {
		this.tenlop = tenlop;
	}
	public Double getDtb() {
		return dtb;
	}
	public void setDtb(Double dtb) {
		this.dtb = dtb;
	}
	public Sinhvienbean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Sinhvienbean(String masv, String hoten ,Boolean gioitinh, Date ngaysinh, String tenlop, Double dtb) {
		super(hoten,gioitinh, ngaysinh);
		this.masv = masv;
		this.tenlop = tenlop;
		this.dtb = dtb;
	}
	@Override
	public String toString() {
		return  masv + ";"+super.toString()+";" +tenlop+";"+ dtb;
	}
	
	
	
	
	
}
