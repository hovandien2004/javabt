package bean;

public class Thongkebean {
	private boolean gioitinh;
	private int soluong;
	//phat sinh 2 ham tao: 1 khong tham so, 1 du tham so
	public Thongkebean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Thongkebean(boolean gioitinh, int soluong) {
		super();
		this.gioitinh = gioitinh;
		this.soluong = soluong;
	}
	//phatsinh ham get, set
	
	public boolean isGioitinh() {
		return gioitinh;
	}
	public void setGioitinh(boolean gioitinh) {
		this.gioitinh = gioitinh;
	}
	public int getSoluong() {
		return soluong;
	}
	public void setSoluong(int soluong) {
		this.soluong = soluong;
	}
	
	
	// phat sinh ham toString
	@Override
	public String toString() {
		return gioitinh + ":" +soluong;
	}
	
	
}
