package bean;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Scanner;

public class chay {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			SimpleDateFormat dd = new SimpleDateFormat("dd/MM/yy");
			Nguoi n1 = new Nguoi("ha", true, dd.parse("10/11/2004"));
			Nguoi n2 = new Nguoi("hung", false, dd.parse("20/01/2004"));
			Nguoi n3 = new Nguoi("Nhu", true, dd.parse("15/12/1995"));
			Nguoi n4 = new Nguoi("Phong", false, dd.parse("23/05/1990"));
			ArrayList<Nguoi> ds = new ArrayList<Nguoi>();
			ds.add(n1);ds.add(n2);ds.add(n3);ds.add(n4);
			for(Nguoi n:ds) {
				System.out.println(n.toString());
			}
			//hien thi nguoi tren 30 tuoi
			System.out.println("\nNguoi tren 30 tuoi:");
			for(Nguoi n: ds) {
				if(n.gettuoi() > 30) {
					System.out.println(n.toString());
				}
			}
			// co bao nhieu nam va nu
			int sonam = 0;
			int sonu = 0;
			
			for(Nguoi n: ds) {
				if(n.getGioitinh().equals(true)) {
					sonam += 1;
				}else {
					sonu += 1;
				}
			}System.out.println("\nSo nam: "+ sonam);
			System.out.println("So nu: "+ sonam);
			
			// nhap vao 1 hoten -> tim theo hoten
			Scanner sc = new Scanner(System.in);
			System.out.println("Nhap nguoi can tim: ");
			String nhap = sc.nextLine();
			
			for(Nguoi n: ds) {
				if(n.gethoten().equals(nhap)) {
					System.out.println(n.toString());
				}
			}
			
			//Luu mang vao file ds.txt
			
			FileWriter f2 = new FileWriter("ds.txt");
			PrintWriter ghi = new PrintWriter(f2);
			for(Nguoi h: ds) {
				ghi.println(h);
			}ghi.close();
			System.out.println("Da luu");
			
			//System.out.println(n1.toString());
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
