package bean;

import java.nio.file.attribute.AclEntry;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Scanner;

public class test {
	public static void main(String[] args) {
		try {
			SimpleDateFormat dd = new SimpleDateFormat("dd/MM/yy");
			Nguoi n1 = new Nguoi("ha", true, dd.parse("10/11/2004"));
			Nguoi n2 = new Nguoi("hung", false, dd.parse("20/01/2004"));
			//Tao ra 2 sinh vien va 2 nhan vien
			Sinhvienbean sv1 = new Sinhvienbean("sv1", "Thu", false, dd.parse("10/11/2004"), "K46l", 5.5);
			System.out.println(sv1.toString());
			Sinhvienbean sv2 = new Sinhvienbean("sv2", "Nhu", true, dd.parse("12/05/2004"), "K46l", 8.5);
			System.out.println(sv2.toString());
			
			Nhanvienbean nv1 = new Nhanvienbean("nv1", "Dien", true, dd.parse("12/05/2004"), "haha@gmail.com", "0123456", 2.34);
			System.out.println(nv1.toString());
			Nhanvienbean nv2 = new Nhanvienbean("nv2", "Phong", false, dd.parse("12/05/2004"), "hovandien@gmail.com", "0145678", 4.54);
			System.out.println(nv2.toString());
			
			//Hien thi thong tin
			//Tao ra 1 mang dong luu 2 nguoi
					//2 sinhvien va 2 nhanvien
			
			ArrayList<Nguoi> ds =new ArrayList<Nguoi>();
			ds.add(n1);ds.add(n2);ds.add(sv1);ds.add(sv2);ds.add(nv1);ds.add(nv2);
			
			//Hien thi all gia tri cua mang ra man hinh
			System.out.println("/nDanh sach trong mang:");
			for(Nguoi n:ds) {
				System.out.println(n.toString());
			}
			//Hien thi ds nhanvien
			System.out.println("\nDanh sach sv thuoc Nhanvien: ");
			for(Object nv:ds) {
				if(nv instanceof Nhanvienbean) {
					Nhanvienbean nv3 = (Nhanvienbean)nv;
					System.out.println(nv3.toString());
					
				}
			}
			//Hien thi ds sinhvien
			System.out.println("\nDanh sach sv thuoc Sinhvien: ");
			for(Object sv:ds) {
				if(sv instanceof Sinhvienbean) {
					Sinhvienbean sv3 = (Sinhvienbean)sv;
					System.out.println(sv3.toString());
					
				}
			}
			
			//hienthi ds Nguoi
			System.out.println("\nDanh sach Nguoi: ");
			for(Object n:ds) {
				if(!(n instanceof Nhanvienbean) && !(n instanceof Sinhvienbean)) {
					Nguoi n3 = (Nguoi)n;
					System.out.println(n3.toString());
					
				}
			}
			double tbcnv = 0.0;
			int dem = 0;
			//Tinh tbc cua hsl cua nhanvien
			System.out.println("\nTBC hsl cua nhanvien: ");
			for(Object nv:ds) {
				if(nv instanceof Nhanvienbean) {
					dem++;
					Nhanvienbean nv3 = (Nhanvienbean)nv;
					tbcnv += nv3.getHsl(); 
					
				}
			}System.out.println("Tbc: " + tbcnv/dem);
			
			//Nhap vao 1 ten lop, hien thi sv cua lop do
			
			Scanner sc = new Scanner(System.in);
			System.out.println("\nNhap ten lop muon tim: ");
			String tenlop = sc.nextLine();
			int check = -1;
			for(Object sv:ds) {
				if(sv instanceof Sinhvienbean) {	
					Sinhvienbean sv3 = (Sinhvienbean)sv;
					if(tenlop.equals(sv3.getTenlop())) {
						check = 1;
						System.out.println("Sinh vien o lop muon tim: " + sv3.toString());
					}
				
				}
			}if(check == -1) {
				System.out.println("Khong co sinh vien o lop muon tim");
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
