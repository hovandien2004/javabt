package bo;
import java.util.ArrayList;

import bean.Nguoi;
import bean.Thongkebean;
import dao.Nguoidao;
public class Nguoibo {
	Nguoidao ndao = new Nguoidao();
	ArrayList<Nguoi> ds;
	public ArrayList<Nguoi> getds() throws Exception{
		ds = ndao.getds();
		return ds;
	}
	public void hienthi() throws Exception{
		for(Nguoi n:ds) {
			System.out.println(n.toString());
		}
	}
	
	public ArrayList<Nguoi> getdstheotuoi(int tuoi) {
		ArrayList<Nguoi> tam = new ArrayList<Nguoi>();
		for(Nguoi n: ds) {
			if(n.gettuoi() >= tuoi) {
				System.out.println(n.toString());
			}
		}
		return tam;
	}
	
	public ArrayList<Thongkebean> thongke() throws Exception{
		ArrayList<Thongkebean> tam= new ArrayList<Thongkebean>();
		int dem = 0;
		for(Nguoi n: ds) {
			if(n.getGioitinh() == true) {
				
				dem++;
			}
		}tam.add(new Thongkebean(true, dem));
		tam.add(new Thongkebean(false, ds.size()- dem));
		return tam;
	}
	
	
	
	
}
