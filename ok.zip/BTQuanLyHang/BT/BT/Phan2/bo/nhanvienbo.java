package bo;

import java.util.ArrayList;

import bean.Nhanvienbean;
import bean.Sinhvienbean;
import dao.Nguoidao;
import dao.ndao;

public class nhanvienbo {
	public ArrayList<Nhanvienbean> ds;
	ndao ndao1 = new ndao();
	public ArrayList<Nhanvienbean> getnv() throws Exception{
		ds = ndao1.getnv();
		return ds;
		
	}
}
