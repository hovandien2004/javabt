package bo;

import java.util.ArrayList;

import bean.Nguoi;
import bean.Sinhvienbean;
import dao.Nguoidao;
import dao.ndao;

public class sinhvienbo {
	public ArrayList<Sinhvienbean> ds;
	ndao ndao1 = new ndao();
	public ArrayList<Sinhvienbean> getsv() throws Exception{
		ds = ndao1.getsv();
		return ds;
		
	}
	//Liet ke all chuc nang cua sinhvien
}
