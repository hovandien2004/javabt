package dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

import bean.Nguoi;
import bean.Nhanvienbean;
import bean.Sinhvienbean;

public class ndao {
	
		public ArrayList<Nguoi> getds() throws Exception{
			SimpleDateFormat dd = new SimpleDateFormat("dd/MM/yy");
			Nguoi n1 = new Nguoi("ha", true, dd.parse("10/11/2004"));
			Nguoi n2 = new Nguoi("hung", false, dd.parse("20/01/2004"));
			//Tao ra 2 sinh vien va 2 nhan vien
			Sinhvienbean sv1 = new Sinhvienbean("sv1", "Thu", false, dd.parse("10/11/2004"), "K46l", 5.5);
			System.out.println(sv1.toString());
			Sinhvienbean sv2 = new Sinhvienbean("sv2", "Nhu", true, dd.parse("12/05/2004"), "K46l", 8.5);
			System.out.println(sv2.toString());
			
			Nhanvienbean nv1 = new Nhanvienbean("nv1", "Dien", true, dd.parse("12/05/2004"), "haha@gmail.com", "0123456", 2.34);
			System.out.println(nv1.toString());
			Nhanvienbean nv2 = new Nhanvienbean("nv2", "Phong", false, dd.parse("12/05/2004"), "hovandien@gmail.com", "0145678", 4.54);
			System.out.println(nv2.toString());
			ArrayList<Nguoi> ds =new ArrayList<Nguoi>();
			ds.add(n1);ds.add(n2);ds.add(sv1);ds.add(sv2);ds.add(nv1);ds.add(nv2);
			return ds;
			
		}	
		public ArrayList<Sinhvienbean> getsv() throws Exception{
			ArrayList<Sinhvienbean> tam = new ArrayList<Sinhvienbean>();
			for(Nguoi n: getds()) {
				if(n instanceof Sinhvienbean) {
					tam.add((Sinhvienbean)n);
				}
			}return tam;
		}
		public ArrayList<Nhanvienbean> getnv() throws Exception{
			ArrayList<Nhanvienbean> tam = new ArrayList<Nhanvienbean>();
			for(Nguoi n: getds()) {
				if(n instanceof Nhanvienbean) {
					tam.add((Nhanvienbean)n);
				}
			}return tam;
		}
		
}
