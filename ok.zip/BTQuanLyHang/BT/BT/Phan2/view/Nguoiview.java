package view;

import java.util.ArrayList;

import bean.Nguoi;
import bean.Thongkebean;
import bo.Nguoibo;

public class Nguoiview {

	public static void main(String[] args) {
		try {
			Nguoibo nbo = new Nguoibo();
			ArrayList<Nguoi> ds = nbo.getds();
			System.out.println("Danh sach: ");
			nbo.hienthi();
			System.out.println("Danh sach tren 30 tuoi: ");
			for(Nguoi n: nbo.getdstheotuoi(30))
				System.out.println(n.toString());
			
			System.out.println("Thong ke");
			for(Thongkebean tk: nbo.thongke())
				System.out.println(tk.toString());
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
		

	}

}
