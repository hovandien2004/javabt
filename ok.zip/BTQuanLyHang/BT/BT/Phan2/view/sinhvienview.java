package view;

import bean.Sinhvienbean;
import bo.sinhvienbo;

public class sinhvienview {
	public static void main(String[] args) {
		try {
			sinhvienbo svbo = new sinhvienbo();
			System.out.println("Danh sach sv:");
			for(Sinhvienbean sv:svbo.getsv()) {
				System.out.println(sv.toString());
			}
		} catch (Exception e) {
			e.getMessage();
			// TODO: handle exception
		}
	}
}
//