import java.util.Comparator;

public class Htron {

	public Htron(int i) {
		// TODO Auto-generated constructor stub
	}
	double r;
	public Htron(double r) {
		super();
		this.r=r;
	}
	public double dienTich() {
		return 3.14*r*r;
	}
	public double chuVi() {
		return 2*3.14*r;
	}
	class SSDT_HTron implements Comparator<Htron>{
		public int compare(Htron x,Htron y ) {
			if(x.dienTich()>y.dienTich())return -1;
			else
				if(x.dienTich()==y.dienTich()) return 0;
				else return -1;
					
		}
		
	}
}
