import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.DirectoryStream.Filter;
import java.util.ArrayList;
import java.util.Scanner;

public class bai3 {
	public static void main(String[] args) {


		String path = "D:\\data.txt";


		ArrayList<String> l = new ArrayList<String> ();


		File f = new File(path);


		if(!f.exists()) {


		System.out.print("Khong ton tai");}


		else


		{


		try


		{


		Scanner sc = new Scanner(f);


		while (sc.hasNextLine())


		{


		l.add(sc.nextLine());


		}


		}


		catch (IOException e)


		{


		e.printStackTrace();


		}


		try


		{


		FileWriter fNam = new FileWriter("D:\\fNam.txt");


		FileWriter fNu = new FileWriter("D:\\fNu.txt");


		for (int i = 0; i < l.size(); i++)


		{


		if (l.get(i).indexOf("Nam") != -1)


		{


		int m = i;


		for (int n = i-2; n <= i; n++)


		{


		fNam.write(l.get(n) + "\n");


		m--;


		}


		}


		if (l.get(i).indexOf("Nu") != -1)


		{


		int m = i;


		for (int n = i-2; n <= i; n++)


		{


		fNu.write(l.get(n) + "\n");


		m--;


		}


		}


		}


		fNam.close();


		fNu.close();


		}


		catch (IOException e)


		{


		e.printStackTrace();


		}


		}


		}


	
		
			

	

}
